#ID (AUTOASIGNADO)

<form>
	Name (encrypted):<br>
	<input type="text" name="username"><br>
	Nick:<br>
	<input type="text" name="nick"><br>
	Sexo:<br>
	<form action="/action_page.php">
		<input type="radio" name="gender" value="male"><br>
		<input type="radio" name="gender" value="female"><br>
		<input type="radio" name="gender" value="other"><br>
	</form>
	Edad:<br>
	#Poner la edad con una lista (de 16 a 99 años f.ex.)
	Especialidad:<br>
	<form>
		<input type="checkbox" name="specialty1" value=""> Sigiloso<br>
		<input type="checkbox" name="specialty2" value=""> Suertudo<br>
		<input type="checkbox" name="specialty3" value=""> Rico<br>
		<input type="checkbox" name="specialty4" value=""> Persuasivo<br>
		<input type="checkbox" name="specialty5" value=""> Agil<br>
		<input type="checkbox" name="specialty6" value=""> Inteligente <br>
	</form>
	Direccion de contacto:<br>
	<input type="text" name="contactInfo"><br>
</form>
